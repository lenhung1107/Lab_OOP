package hust.soict.dsai.aims.media;

//Create Playable interface
public interface Playable {
    void play();
}