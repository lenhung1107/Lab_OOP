package lab_01;


import java.util.Scanner;

import javax.swing.JOptionPane;

public class hello {
    public static void main(String[] args) {
    	//System.out.println("Le Thi Nhung 20210662");
    	JOptionPane.showMessageDialog(null, " Le Thi Nhung 20210662 Hello world! How are you?");
    	System.exit(0);
    	
    	
    	}
}
