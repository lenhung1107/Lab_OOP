package lab_01;

import javax.swing.JOptionPane;

public class ex3 {
	public static void main(String[] args) {
		
		String result;
		result=JOptionPane.showInputDialog("Le Thi Nhung 20210662 Please enter your name:");
		JOptionPane.showMessageDialog(null, "Hi " + result +"!");
		System.exit(0);
	}

}
