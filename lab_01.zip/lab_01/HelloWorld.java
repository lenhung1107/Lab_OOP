package lab_01;

//Exarple 1: HelloWorld.java
//Text-printing program
public class HelloWorld {
    //main method begins execution of Java application
    public static void main(String[] args) {
    	System.out.println("Lê Thị Nhung 20210662");
        System.out.println("Xin chao \n cac ban!");
        System.out.println("Hello \t World!");
    }//end method main
}//end class HelloWorld
